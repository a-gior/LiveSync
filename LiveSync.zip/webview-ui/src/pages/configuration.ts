import App from "./../components/Configuration.svelte";

const app = new App({
  target: document.body,
});

export default app;
