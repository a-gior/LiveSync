export type BooleanCallableFunction = (...args: any[]) => boolean;
