export interface SFTPError {
  msg: string;
  error: any;
}
