export interface Message {
  command: string;
  [key: string]: any;
}
