import * as fs from "fs";
import * as path from "path";
import { SFTPClient } from "../../services/SFTPClient";
import { generateHash } from "./hashUtils";
import { FileNodeSource } from "../FileNode";
import { SSHClient } from "../../services/SSHClient";
import { window } from "vscode";
import { ConnectionManager } from "../../services/ConnectionManager";
import sftp from "ssh2-sftp-client";
import { WorkspaceManager } from "../../services/WorkspaceConfig";
import { shouldIgnore } from "../shouldIgnore";
import { logErrorMessage, logInfoMessage } from "../../services/LogManager";
import { BaseNodeType } from "../BaseNode";
import JsonManager, {
  isFileNodeMap,
  JsonType,
} from "../../services/JsonManager";

export async function downloadRemoteFile(
  remotePath: string,
  localPath: string,
): Promise<void> {
  const configuration = WorkspaceManager.getRemoteServerConfigured();
  const connectionManager = ConnectionManager.getInstance(configuration);

  if (shouldIgnore(remotePath)) {
    return;
  }

  try {
    await connectionManager.doSFTPOperation(async (sftpClient: SFTPClient) => {
      const dir = path.dirname(localPath);
      await fs.promises.mkdir(dir, { recursive: true });
      await sftpClient.downloadFile(remotePath, localPath);
    }, `Download ${remotePath}`);

    logInfoMessage(`File ${localPath} download to ${remotePath}`);
  } catch (error: any) {
    logErrorMessage(`Failed to download file: ${error.message}`);
    throw error;
  }
}

export async function uploadRemoteFile(
  localPath: string,
  remotePath: string,
  checkParentDirExists: boolean = true,
): Promise<void> {
  const configuration = WorkspaceManager.getRemoteServerConfigured();
  const connectionManager = ConnectionManager.getInstance(configuration);

  if (shouldIgnore(localPath)) {
    return;
  }

  try {
    await connectionManager.doSFTPOperation(async (sftpClient: SFTPClient) => {
      const remoteDir = path.dirname(remotePath);
      if (checkParentDirExists) {
        const dirExists = await sftpClient.pathExists(remoteDir);
        if (!dirExists) {
          await sftpClient.createDirectory(remoteDir);
        }
      }
      await sftpClient.uploadFile(localPath, remotePath);
    }, `Upload to ${remotePath}`);

    logInfoMessage(`File ${localPath} uploaded to ${remotePath}`);
  } catch (error: any) {
    logErrorMessage(`Failed to upload file: ${error.message}`);
    throw error;
  }
}

// Compare remote file hash with stored remote hash
export async function compareRemoteFileHash(
  remotePath: string,
): Promise<boolean> {
  try {
    // Get the remote JSON entries
    const remoteFileEntriesMap =
      await JsonManager.getInstance().getFileEntriesMap(JsonType.REMOTE);
    if (!remoteFileEntriesMap || !isFileNodeMap(remoteFileEntriesMap)) {
      logErrorMessage(`No remote JSON found`);
      return false;
    }
    const remoteEntry = await JsonManager.findNodeByPath(
      remotePath,
      remoteFileEntriesMap,
    );
    if (!remoteEntry) {
      logErrorMessage(`No remote FileNode found`);
      return false;
    }

    const remoteFileHash = await generateHash(
      remotePath,
      FileNodeSource.remote,
      BaseNodeType.file,
    );

    return remoteEntry.hash === remoteFileHash;
  } catch (error) {
    console.error("Error comparing remote file hash:", error);
    return false;
  }
}

export async function getRemoteFileContentHash(
  remotePath: string,
): Promise<string | undefined> {
  const configuration = WorkspaceManager.getRemoteServerConfigured();
  const connectionManager = ConnectionManager.getInstance(configuration);

  const command = `sha256sum "${remotePath}" | awk '{ print $1 }'`;
  let fileHash: string | undefined;

  try {
    await connectionManager.doSSHOperation(async (sshClient: SSHClient) => {
      const hash = await sshClient.executeCommand(command);
      fileHash = hash.trim(); // Ensure any extra whitespace is removed
    }, `Get remote hash of ${remotePath}`);
  } catch (err) {
    window.showErrorMessage("Error getting remote file hash");
    console.error(
      `Error getting remote file hash on \n\t${remotePath} \nwith command \n\t${command}`,
    );
  }

  return fileHash;
}

export async function remotePathExists(remotePath: string) {
  const configuration = WorkspaceManager.getRemoteServerConfigured();
  const connectionManager = ConnectionManager.getInstance(configuration);

  return await connectionManager.doSFTPOperation(
    async (sftpClient: SFTPClient) => {
      return await sftpClient.pathExists(remotePath);
    },
    `Checking if ${remotePath} exists`,
  );
}

export async function getRemoteFileMetadata(
  remotePath: string,
): Promise<sftp.FileStats | undefined> {
  const configuration = WorkspaceManager.getRemoteServerConfigured();
  const connectionManager = ConnectionManager.getInstance(configuration);

  try {
    return await connectionManager.doSFTPOperation(
      async (sftpClient: SFTPClient) => {
        return await sftpClient.getFileStats(remotePath);
      },
      `Get data from ${remotePath}`,
    );
  } catch (err: any) {
    console.error(`Couldn't fetch metadata for remote file ${remotePath}`);
  }
}

export async function moveRemoteFile(
  oldRemotePath: string,
  newRemotePath: string,
): Promise<void> {
  const configuration = WorkspaceManager.getRemoteServerConfigured();
  const connectionManager = ConnectionManager.getInstance(configuration);

  if (shouldIgnore(oldRemotePath)) {
    return;
  }

  try {
    await connectionManager.doSFTPOperation(async (sftpClient: SFTPClient) => {
      await sftpClient.moveFile(oldRemotePath, newRemotePath);
    }, `Move file from ${oldRemotePath} to ${newRemotePath}`);
  } catch (error: any) {
    console.error(`Failed to move remote file: ${error.message}`);
    window.showErrorMessage(`Failed to move remote file: ${error.message}`);
  }
}

export async function deleteRemoteFile(remotePath: string): Promise<void> {
  const configuration = WorkspaceManager.getRemoteServerConfigured();
  const connectionManager = ConnectionManager.getInstance(configuration);

  if (shouldIgnore(remotePath)) {
    return;
  }

  try {
    await connectionManager.doSFTPOperation(async (sftpClient: SFTPClient) => {
      await sftpClient.deleteFile(remotePath);
    }, `Delete ${remotePath}`);
  } catch (error: any) {
    console.error(`Failed to delete remote file: ${error.message}`);
    window.showErrorMessage(`Failed to delete remote file: ${error.message}`);
  }
}
